-- ============================================================
-- 026_h26_cadastro_setor_HML_PREFLIGHT_GAIA.sql
-- Projeto FugaPET_HML
-- Banco PostgreSQL - Schema homologacao
-- Objeto: Cadastro de Setor
--
-- OBJETIVO
--   Validar dados atuais antes de aplicar o incremental 026.
--   NAO altera estrutura nem dados.
-- ============================================================

SET search_path TO homologacao;

-- Resultado detalhado do preflight.
SELECT 'nome_setor_fora_limite_2_80' AS validacao, count(*)::bigint AS quantidade
  FROM homologacao.setor
 WHERE nome_setor IS NULL
    OR char_length(trim(nome_setor)) < 2
    OR char_length(trim(nome_setor)) > 80
UNION ALL
SELECT 'descricao_setor_maior_255', count(*)::bigint
  FROM homologacao.setor
 WHERE descricao_setor IS NOT NULL
   AND char_length(trim(descricao_setor)) > 255
UNION ALL
SELECT 'setores_ativos_duplicados_upper_trim', count(*)::bigint
  FROM (
        SELECT upper(trim(nome_setor)) AS nome_normalizado, count(*) AS qtd
          FROM homologacao.setor
         WHERE situacao_setor = true
         GROUP BY upper(trim(nome_setor))
        HAVING count(*) > 1
       ) d
UNION ALL
SELECT 'usuarios_ativos_setor_padrao_inativo', count(*)::bigint
  FROM homologacao.usuario u
  JOIN homologacao.setor s ON s.codigo_setor = u.codigo_setor_padrao
 WHERE u.situacao_usuario = true
   AND s.situacao_setor = false
UNION ALL
SELECT 'usuario_setor_ativo_setor_inativo', count(*)::bigint
  FROM homologacao.usuario_setor us
  JOIN homologacao.setor s ON s.codigo_setor = us.codigo_setor
 WHERE us.situacao_usuario_setor = true
   AND s.situacao_setor = false
UNION ALL
SELECT 'balancas_ativas_setor_inativo', count(*)::bigint
  FROM homologacao.balanca b
  JOIN homologacao.setor s ON s.codigo_setor = b.codigo_setor
 WHERE b.situacao_balanca = true
   AND s.situacao_setor = false
UNION ALL
SELECT 'taras_ativas_setor_inativo', count(*)::bigint
  FROM homologacao.tara t
  JOIN homologacao.setor s ON s.codigo_setor = t.codigo_setor
 WHERE t.situacao_tara = true
   AND s.situacao_setor = false
UNION ALL
SELECT 'parametros_operacionais_ativos_setor_inativo', count(*)::bigint
  FROM homologacao.parametro_operacao po
  JOIN homologacao.setor s ON s.codigo_setor = po.codigo_setor
 WHERE po.situacao_parametro_operacao = true
   AND s.situacao_setor = false
UNION ALL
SELECT 'lancamentos_operacionais_ativos_setor_inativo', count(*)::bigint
  FROM homologacao.entrada_produto_lancamento epl
  JOIN homologacao.setor s ON s.codigo_setor = epl.codigo_setor
 WHERE epl.situacao_entrada_produto_lancamento = true
   AND epl.status_lancamento NOT IN ('CONFIRMADO_SAP', 'CANCELADO')
   AND s.situacao_setor = false;

-- Bloqueio do preflight se houver qualquer inconsistencia relevante.
DO $$
DECLARE
    v_total integer;
BEGIN
    SELECT count(*) INTO v_total
      FROM homologacao.setor
     WHERE nome_setor IS NULL
        OR char_length(trim(nome_setor)) < 2
        OR char_length(trim(nome_setor)) > 80;
    IF v_total > 0 THEN
        RAISE EXCEPTION 'Preflight 026 bloqueado: existem % setores com nome_setor fora do limite 2..80.', v_total;
    END IF;

    SELECT count(*) INTO v_total
      FROM homologacao.setor
     WHERE descricao_setor IS NOT NULL
       AND char_length(trim(descricao_setor)) > 255;
    IF v_total > 0 THEN
        RAISE EXCEPTION 'Preflight 026 bloqueado: existem % setores com descricao_setor maior que 255 caracteres.', v_total;
    END IF;

    SELECT count(*) INTO v_total
      FROM (
            SELECT upper(trim(nome_setor)) AS nome_normalizado, count(*) AS qtd
              FROM homologacao.setor
             WHERE situacao_setor = true
             GROUP BY upper(trim(nome_setor))
            HAVING count(*) > 1
           ) d;
    IF v_total > 0 THEN
        RAISE EXCEPTION 'Preflight 026 bloqueado: existem % nomes de setor ativos duplicados por upper(trim(nome_setor)).', v_total;
    END IF;

    SELECT count(*) INTO v_total
      FROM homologacao.usuario u
      JOIN homologacao.setor s ON s.codigo_setor = u.codigo_setor_padrao
     WHERE u.situacao_usuario = true
       AND s.situacao_setor = false;
    IF v_total > 0 THEN
        RAISE EXCEPTION 'Preflight 026 bloqueado: existem % usuarios ativos com setor padrao inativo.', v_total;
    END IF;

    SELECT count(*) INTO v_total
      FROM homologacao.usuario_setor us
      JOIN homologacao.setor s ON s.codigo_setor = us.codigo_setor
     WHERE us.situacao_usuario_setor = true
       AND s.situacao_setor = false;
    IF v_total > 0 THEN
        RAISE EXCEPTION 'Preflight 026 bloqueado: existem % vinculos usuario_setor ativos com setor inativo.', v_total;
    END IF;

    SELECT count(*) INTO v_total
      FROM homologacao.balanca b
      JOIN homologacao.setor s ON s.codigo_setor = b.codigo_setor
     WHERE b.situacao_balanca = true
       AND s.situacao_setor = false;
    IF v_total > 0 THEN
        RAISE EXCEPTION 'Preflight 026 bloqueado: existem % balancas ativas vinculadas a setor inativo.', v_total;
    END IF;

    SELECT count(*) INTO v_total
      FROM homologacao.tara t
      JOIN homologacao.setor s ON s.codigo_setor = t.codigo_setor
     WHERE t.situacao_tara = true
       AND s.situacao_setor = false;
    IF v_total > 0 THEN
        RAISE EXCEPTION 'Preflight 026 bloqueado: existem % taras ativas vinculadas a setor inativo.', v_total;
    END IF;

    SELECT count(*) INTO v_total
      FROM homologacao.parametro_operacao po
      JOIN homologacao.setor s ON s.codigo_setor = po.codigo_setor
     WHERE po.situacao_parametro_operacao = true
       AND s.situacao_setor = false;
    IF v_total > 0 THEN
        RAISE EXCEPTION 'Preflight 026 bloqueado: existem % parametros operacionais ativos vinculados a setor inativo.', v_total;
    END IF;

    SELECT count(*) INTO v_total
      FROM homologacao.entrada_produto_lancamento epl
      JOIN homologacao.setor s ON s.codigo_setor = epl.codigo_setor
     WHERE epl.situacao_entrada_produto_lancamento = true
       AND epl.status_lancamento NOT IN ('CONFIRMADO_SAP', 'CANCELADO')
       AND s.situacao_setor = false;
    IF v_total > 0 THEN
        RAISE EXCEPTION 'Preflight 026 bloqueado: existem % lancamentos operacionais ativos vinculados a setor inativo.', v_total;
    END IF;
END $$;

SELECT 'PREFLIGHT 026 HML APROVADO - SEM INCONSISTENCIAS BLOQUEANTES' AS resultado_preflight;
