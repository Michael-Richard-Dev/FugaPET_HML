-- ============================================================
-- 026_h26_cadastro_setor_regras_banco_HML_ROLLBACK_GAIA.sql
-- Rollback do incremental 026 para regras de banco do Cadastro de Setor.
-- Projeto FugaPET_HML - Schema homologacao
-- NAO executar automaticamente.
-- ============================================================

SET search_path TO homologacao;

BEGIN;

DROP TRIGGER IF EXISTS trg_setor_bloquear_inativacao_em_uso ON homologacao.setor;
DROP FUNCTION IF EXISTS homologacao.fn_bloquear_inativacao_setor_em_uso();
DROP VIEW IF EXISTS homologacao.vw_setor_diagnostico_inativacao;
DROP FUNCTION IF EXISTS homologacao.fn_setor_dependencias_ativas(bigint);

DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conrelid = 'homologacao.setor'::regclass
          AND conname = 'ck_setor_nome_tamanho_funcional'
    ) THEN
        ALTER TABLE homologacao.setor DROP CONSTRAINT ck_setor_nome_tamanho_funcional;
    END IF;

    IF EXISTS (
        SELECT 1 FROM pg_constraint
        WHERE conrelid = 'homologacao.setor'::regclass
          AND conname = 'ck_setor_descricao_tamanho_funcional'
    ) THEN
        ALTER TABLE homologacao.setor DROP CONSTRAINT ck_setor_descricao_tamanho_funcional;
    END IF;
END $$;

COMMIT;
