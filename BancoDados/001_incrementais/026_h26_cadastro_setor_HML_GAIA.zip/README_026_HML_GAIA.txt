PACOTE 026 - CADASTRO DE SETOR - FUGAPET_HML - GAIA DADOS

Schema oficial usado: homologacao
Banco alvo previsto: fuga_jales_local_homologacao_v1_2
Producao: NAO aplicar.

Arquivos:
1. 026_h26_cadastro_setor_HML_PREFLIGHT_GAIA.sql
   - Executar antes do incremental.
   - Nao altera dados nem estrutura.
   - Bloqueia se houver inconsistencias atuais.

2. 026_h26_cadastro_setor_regras_banco_HML_PROPOSTA_GAIA.sql
   - Aplica CHECKs de tamanho para setor.
   - Cria funcao fn_setor_dependencias_ativas.
   - Cria view vw_setor_diagnostico_inativacao.
   - Cria trigger trg_setor_bloquear_inativacao_em_uso.
   - Bloqueia inativacao logica de setor em uso.

3. 026_h26_cadastro_setor_validacao_002_HML_APPEND_GAIA.sql
   - Validacao complementar apos aplicacao.
   - Confirma objetos, checks, triggers e inconsistencias de dados.

4. 026_h26_cadastro_setor_regras_banco_HML_ROLLBACK_GAIA.sql
   - Remove trigger, funcoes, view e constraints funcionais.
   - Nao remove dados.

Ordem segura:
1. Snapshot/backup da VM/banco.
2. Executar preflight.
3. Se preflight aprovar, executar proposta.
4. Executar validacao 002 append.
5. Testar Cadastro de Setor na aplicacao.

Comandos sugeridos:
sudo -u postgres psql -v ON_ERROR_STOP=1 -d fuga_jales_local_homologacao_v1_2 -f 026_h26_cadastro_setor_HML_PREFLIGHT_GAIA.sql
sudo -u postgres psql -v ON_ERROR_STOP=1 -d fuga_jales_local_homologacao_v1_2 -f 026_h26_cadastro_setor_regras_banco_HML_PROPOSTA_GAIA.sql
sudo -u postgres psql -v ON_ERROR_STOP=1 -d fuga_jales_local_homologacao_v1_2 -f 026_h26_cadastro_setor_validacao_002_HML_APPEND_GAIA.sql
