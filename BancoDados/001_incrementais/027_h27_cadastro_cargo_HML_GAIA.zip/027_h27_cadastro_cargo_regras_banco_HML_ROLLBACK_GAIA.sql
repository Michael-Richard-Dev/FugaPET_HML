-- ============================================================
-- 027_h27_cadastro_cargo_regras_banco_HML_ROLLBACK_GAIA.sql
-- Projeto FugaPET_HML
-- Banco PostgreSQL - Banco alvo: fuga_jales_local_homologacao_v1_2
-- Schema alvo: homologacao
-- Objeto: Cadastro de Cargo
--
-- OBJETIVO
--   Rollback estrutural do incremental 027 HML.
--   Nao altera dados da tabela cargo nem usuario.
--   NAO executar em producao.
-- ============================================================

SET search_path TO homologacao;

BEGIN;

DROP TRIGGER IF EXISTS trg_cargo_bloquear_inativacao_em_uso ON homologacao.cargo;

DROP FUNCTION IF EXISTS homologacao.fn_cargo_bloquear_inativacao_em_uso();

DROP VIEW IF EXISTS homologacao.vw_cargo_diagnostico_inativacao;

DROP FUNCTION IF EXISTS homologacao.fn_cargo_dependencias_ativas(bigint);

ALTER TABLE homologacao.cargo
    DROP CONSTRAINT IF EXISTS ck_cargo_descricao_tamanho_funcional;

ALTER TABLE homologacao.cargo
    DROP CONSTRAINT IF EXISTS ck_cargo_nome_tamanho_funcional;

COMMIT;

SELECT 'ROLLBACK 027 CARGO HML EXECUTADO - OBJETOS INCREMENTAIS REMOVIDOS' AS resultado_rollback;
