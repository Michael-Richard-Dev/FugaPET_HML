README - 027 H27 CADASTRO CARGO - HML - GAIA DADOS
=======================================================

Projeto: FugaPET_HML
Banco alvo: fuga_jales_local_homologacao_v1_2
Schema alvo: homologacao
Objeto: Cadastro de Cargo

OBJETIVO
--------
Pacote incremental HML para aplicar regras de banco no Cadastro de Cargo,
seguindo o mesmo padrao aprovado no Cadastro de Setor.

REGRAS FUNCIONAIS APROVADAS
---------------------------
1. nome_cargo deve ter minimo 2 e maximo 80 caracteres uteis apos trim.
2. descricao_cargo deve ter no maximo 255 caracteres uteis apos trim.
3. Cargo em uso por usuario ativo nao pode ser inativado.
4. A aplicacao deve validar antes, mas o banco deve bloquear bypass por SQL direto.

ARQUIVOS
--------
1. 027_h27_cadastro_cargo_HML_PREFLIGHT_GAIA.sql
   - Valida schema/tabelas e dados atuais.
   - Nao altera estrutura nem dados.

2. 027_h27_cadastro_cargo_regras_banco_HML_PROPOSTA_GAIA.sql
   - Aplica constraints funcionais.
   - Cria funcao de dependencias.
   - Cria view de diagnostico.
   - Cria funcao/trigger de bloqueio de inativacao.
   - Executa em transacao.
   - Nao altera dados existentes.

3. 027_h27_cadastro_cargo_validacao_002_HML_APPEND_GAIA.sql
   - Valida objetos criados e inconsistencias.
   - Nao altera dados.

4. 027_h27_cadastro_cargo_regras_banco_HML_ROLLBACK_GAIA.sql
   - Remove trigger, funcoes, view e constraints incrementais.
   - Nao altera dados.

ORDEM SEGURA DE APLICACAO
-------------------------
1. Fazer snapshot/backup do banco HML.
2. Copiar este pacote para a VM HML.
3. Executar o preflight:

   sudo -u postgres psql \
     -v ON_ERROR_STOP=1 \
     -d fuga_jales_local_homologacao_v1_2 \
     -f 027_h27_cadastro_cargo_HML_PREFLIGHT_GAIA.sql \
     2>&1 | tee logs/027_h27_cadastro_cargo_HML_PREFLIGHT_GAIA.log

4. Aplicar o incremental somente se o preflight aprovar:

   sudo -u postgres psql \
     -v ON_ERROR_STOP=1 \
     -d fuga_jales_local_homologacao_v1_2 \
     -f 027_h27_cadastro_cargo_regras_banco_HML_PROPOSTA_GAIA.sql \
     2>&1 | tee logs/027_h27_cadastro_cargo_regras_banco_HML_PROPOSTA_GAIA.log

5. Executar a validacao:

   sudo -u postgres psql \
     -v ON_ERROR_STOP=1 \
     -d fuga_jales_local_homologacao_v1_2 \
     -f 027_h27_cadastro_cargo_validacao_002_HML_APPEND_GAIA.sql \
     2>&1 | tee logs/027_h27_cadastro_cargo_validacao_002_HML_APPEND_GAIA.log

6. Testar no FugaPET_HML:
   - criar cargo com nome menor que 2 caracteres: deve bloquear;
   - criar cargo com nome maior que 80 caracteres: deve bloquear;
   - criar cargo com descricao maior que 255 caracteres: deve bloquear;
   - inativar cargo sem usuario ativo: deve permitir;
   - inativar cargo com usuario ativo: deve bloquear.

RISCOS
------
1. Se existirem cargos com nomes fora de 2..80, o preflight reprova.
2. Se existirem descricoes acima de 255 caracteres, o preflight reprova.
3. Se existirem cargos ativos duplicados por upper(trim(nome_cargo)), o preflight reprova.
4. Se existirem usuarios ativos vinculados a cargos inativos, o preflight reprova.
5. A aplicacao deve consultar homologacao.vw_cargo_diagnostico_inativacao antes de inativar, para exibir mensagem amigavel.
6. O trigger existe para proteger o banco contra bypass por SQL direto.

OBSERVACOES
-----------
- Este pacote e especifico para HML/schema homologacao.
- Nao aplicar em producao.
- Nao altera baseline.
- Nao cria objetos em schema desenvolvimento.
