README 028 H28 - CADASTRO DE BALANCA - HML - GAIA DADOS

Projeto: FugaPET_HML
Banco alvo: fuga_jales_local_homologacao_v1_2
Schema alvo: homologacao
Producao: NAO usar
Baseline: NAO alterar

OBJETIVO
Aplicar no HML as regras de banco aprovadas para Cadastro de Balanca, equivalentes ao padrao ja aplicado em Setor e Cargo:
- limites funcionais de campos;
- validacao tecnica por tipo de conexao;
- diagnostico de dependencias operacionais;
- bloqueio de inativacao logica de balanca em uso.

ARQUIVOS
1. 028_h28_cadastro_balanca_HML_PREFLIGHT_GAIA.sql
   Valida schema, tabelas e dados atuais. Nao cria objetos e nao altera dados.

2. 028_h28_cadastro_balanca_regras_banco_HML_PROPOSTA_GAIA.sql
   Aplica incremental em transacao. Cria constraints, funcoes, view e trigger.

3. 028_h28_cadastro_balanca_validacao_002_HML_APPEND_GAIA.sql
   Validacao complementar equivalente ao append do 002 para HML.

4. 028_h28_cadastro_balanca_regras_banco_HML_ROLLBACK_GAIA.sql
   Remove trigger, funcoes, view e constraints novas. Nao altera dados.

REGRAS FUNCIONAIS
- nome_balanca: 2 a 80 caracteres uteis apos trim.
- identificacao_local: ate 120 caracteres uteis.
- endereco_ip: obrigatorio somente para TCP_IP.
- porta_tcp: obrigatoria somente para TCP_IP, entre 1 e 65535.
- porta_serial: obrigatoria somente para SERIAL, maximo 50 caracteres.
- tipo_conexao: SERIAL, TCP_IP, USB ou MANUAL.
- baud_rate: obrigatorio para SERIAL.
- data_bits: obrigatorio para SERIAL.
- paridade: NONE, EVEN, ODD, MARK ou SPACE.
- stop_bits: 1, 1.5 ou 2.
- flow_control: opcional; quando preenchido, NONE, XON_XOFF, RTS_CTS ou DTR_DSR.
- protocolo: ate 50 caracteres uteis.
- observacao: ate 255 caracteres uteis.
- USB exige identificacao_local.
- MANUAL nao exige dados fisicos.
- Balanca em uso operacional nao pode ser inativada.

OBJETOS CRIADOS
- ck_balanca_nome_tamanho_funcional
- ck_balanca_identificacao_local_tamanho
- ck_balanca_porta_serial_tamanho
- ck_balanca_paridade_valores
- ck_balanca_stop_bits_valores
- ck_balanca_flow_control_valores
- ck_balanca_protocolo_tamanho
- ck_balanca_observacao_tamanho
- ck_balanca_tcp_ip_campos_obrigatorios
- ck_balanca_serial_campos_obrigatorios
- ck_balanca_usb_identificacao_obrigatoria
- homologacao.fn_balanca_dependencias_ativas(bigint)
- homologacao.vw_balanca_diagnostico_inativacao
- homologacao.fn_balanca_bloquear_inativacao_em_uso()
- trg_balanca_bloquear_inativacao_em_uso

DEPENDENCIAS OPERACIONAIS AVALIADAS
- entrada_produto_pesagem ativa;
- hu_caixa ativa;
- hu_caixa_pesagem ativa;
- pesagem_entrada_item ativa;
- pesagem_entrada_item_leitura ativa.

ORDEM SEGURA DE APLICACAO
1. Confirmar snapshot/backup da VM/banco HML.
2. Transferir este pacote para a VM HML.
3. Validar SHA-256 do ZIP.
4. Extrair em pasta propria.
5. Executar somente o preflight:

   sudo -u postgres psql      -v ON_ERROR_STOP=1      -d fuga_jales_local_homologacao_v1_2      -f 028_h28_cadastro_balanca_HML_PREFLIGHT_GAIA.sql      2>&1 | tee logs/028_h28_cadastro_balanca_HML_PREFLIGHT_GAIA.log

6. Se o preflight aprovar, executar o script principal:

   sudo -u postgres psql      -v ON_ERROR_STOP=1      -d fuga_jales_local_homologacao_v1_2      -f 028_h28_cadastro_balanca_regras_banco_HML_PROPOSTA_GAIA.sql      2>&1 | tee logs/028_h28_cadastro_balanca_regras_banco_HML_PROPOSTA_GAIA.log

7. Executar a validacao complementar:

   sudo -u postgres psql      -v ON_ERROR_STOP=1      -d fuga_jales_local_homologacao_v1_2      -f 028_h28_cadastro_balanca_validacao_002_HML_APPEND_GAIA.sql      2>&1 | tee logs/028_h28_cadastro_balanca_validacao_002_HML_APPEND_GAIA.log

8. Testar no FugaPET_HML:
   - criar/editar balanca SERIAL;
   - criar/editar balanca TCP_IP;
   - criar/editar balanca USB;
   - criar/editar balanca MANUAL;
   - tentar salvar campos fora de limite;
   - tentar inativar balanca sem uso;
   - tentar inativar balanca com uso operacional.

RISCOS
- O preflight pode reprovar se houver dados legados fora do padrao aprovado.
- A aplicacao deve validar antes para entregar mensagem amigavel ao usuario.
- O banco bloqueia bypass por SQL direto, entao telas antigas/importacoes tambem passam a respeitar as regras.
- Nao aplicar em producao.

ROLLBACK
Executar somente se for necessario remover os objetos novos do incremental:

sudo -u postgres psql   -v ON_ERROR_STOP=1   -d fuga_jales_local_homologacao_v1_2   -f 028_h28_cadastro_balanca_regras_banco_HML_ROLLBACK_GAIA.sql

O rollback nao altera dados existentes.
