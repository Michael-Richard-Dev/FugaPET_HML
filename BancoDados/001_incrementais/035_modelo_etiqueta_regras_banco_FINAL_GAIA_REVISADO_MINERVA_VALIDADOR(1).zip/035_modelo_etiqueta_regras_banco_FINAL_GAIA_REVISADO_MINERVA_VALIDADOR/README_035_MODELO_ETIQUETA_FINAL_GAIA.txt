README — INCREMENTAL 035 MODELO DE ETIQUETA — FINAL REVISADO MINERVA/GAIA
Projeto: FugaPET
Responsavel pelo projeto: Michael Richard
Objeto: Cadastro de Modelo de Etiqueta
Incremental: 035

IMPORTANTE
- Nenhum script foi executado durante a geracao deste pacote.
- Nenhum dado foi alterado durante a geracao deste pacote.
- Nenhum commit foi realizado.
- Nao contem scripts de PRD.
- Aplicar primeiro em DEV, depois em HML.

ARQUIVOS
DEV:
1. 035_modelo_etiqueta_preflight_DEV.sql
2. 035_modelo_etiqueta_aplicar_DEV.sql
3. 035_modelo_etiqueta_validar_DEV.sql
4. 035_modelo_etiqueta_rollback_DEV.sql

HML:
5. 035_modelo_etiqueta_preflight_HML.sql
6. 035_modelo_etiqueta_aplicar_HML.sql
7. 035_modelo_etiqueta_validar_HML.sql
8. 035_modelo_etiqueta_rollback_HML.sql

Documentacao:
9. README_035_MODELO_ETIQUETA_FINAL_GAIA.txt

ORDEM DE EXECUCAO RECOMENDADA
DEV:
psql -v ON_ERROR_STOP=1 -d <banco_dev> -f 035_modelo_etiqueta_preflight_DEV.sql
psql -v ON_ERROR_STOP=1 -d <banco_dev> -f 035_modelo_etiqueta_aplicar_DEV.sql
psql -v ON_ERROR_STOP=1 -d <banco_dev> -f 035_modelo_etiqueta_validar_DEV.sql

Depois testar a aplicacao em DEV.

HML:
psql -v ON_ERROR_STOP=1 -d <banco_hml> -f 035_modelo_etiqueta_preflight_HML.sql
psql -v ON_ERROR_STOP=1 -d <banco_hml> -f 035_modelo_etiqueta_aplicar_HML.sql
psql -v ON_ERROR_STOP=1 -d <banco_hml> -f 035_modelo_etiqueta_validar_HML.sql

Depois testar a aplicacao em HML.

ROLLBACK
Executar rollback somente em necessidade real e apos decisao tecnica.
psql -v ON_ERROR_STOP=1 -d <banco_dev> -f 035_modelo_etiqueta_rollback_DEV.sql
psql -v ON_ERROR_STOP=1 -d <banco_hml> -f 035_modelo_etiqueta_rollback_HML.sql


REVISAO FINAL DO VALIDADOR — MINERVA/GAIA
- Causa do falso negativo: o validador anterior comparava trecho textual de pg_get_triggerdef exigindo schema qualificado em EXECUTE FUNCTION. Com SET search_path ativo, o PostgreSQL pode retornar a definicao sem qualificar o schema, embora o trigger esteja funcionalmente correto.
- Corrigidos somente os validadores DEV e HML.
- A validacao do trigger agora e feita por catalogos PostgreSQL: pg_trigger, pg_class, pg_namespace, pg_proc e pg_attribute.
- A validacao confirma schema/tabela, nome do trigger, trigger nao interno, habilitado, BEFORE, UPDATE, FOR EACH ROW, coluna situacao_modelo_etiqueta, funcao associada, schema da funcao e nome da funcao.
- pg_get_triggerdef permanece apenas como diagnostico informativo em caso de falha, nao como criterio unico de aprovacao.
- As verificacoes de indice e constraints foram mantidas/revisadas com comparacoes normalizadas e tolerantes a formatacao, capitalizacao, parenteses e casts adicionados pelo PostgreSQL.
- O HML ja pode executar somente: psql -v ON_ERROR_STOP=1 -d <banco_hml> -f 035_modelo_etiqueta_validar_HML.sql
- Nao reaplicar 035_modelo_etiqueta_aplicar_HML.sql quando o preflight ja indicar PACOTE_COMPLETAMENTE_APLICADO.
- Nao executar rollback, salvo decisao tecnica separada.

ALTERACOES REALIZADAS NESTA REVISAO
1. Adicionada diretiva \set ON_ERROR_STOP on nos oito scripts SQL.
2. README reforcado para usar psql -v ON_ERROR_STOP=1 -f <arquivo.sql>.
3. Corrigido diagnostico textual de funcao e trigger nos preflights, sem converter funcao/trigger para regclass.
4. Adicionado comentario de propriedade nos objetos criados pelo pacote:
   FugaPET incremental 035 modelo_etiqueta
5. Rollback ajustado para remover somente objetos com comentario de propriedade do pacote 035.
6. Rollback preserva obrigatoriamente:
   - ck_modelo_etiqueta_versao
   - ck_modelo_etiqueta_zpl_nao_vazio
   - ck_modelo_etiqueta_nome_nao_vazio
7. Adicionado teste transacional de etiqueta inativa:
   - etiqueta ativa bloqueia inativacao;
   - etiqueta inativa nao bloqueia inativacao.
8. Validadores reforcados para conferir definicoes, nao apenas nomes:
   - indice global unique, tabela correta, sem WHERE e expressao upper(trim(nome)) + versao;
   - trigger BEFORE UPDATE OF situacao_modelo_etiqueta, FOR EACH ROW, funcao correta e habilitado;
   - checks novos com definicao funcional esperada.
9. Aplicar e rollback receberam:
   SET LOCAL lock_timeout = '10s';
   SET LOCAL statement_timeout = '2min';
10. Nao foi utilizado CREATE INDEX CONCURRENTLY porque os scripts sao transacionais e a tabela possui poucos registros.
11. Mantido tipo_etiqueta = 'OUTRA' nos testes.
12. Mantida ausencia de PRD.

OBJETOS CRIADOS/GARANTIDOS PELO APLICAR
- uq_modelo_etiqueta_nome_versao_global
- fn_bloqueia_inativar_modelo_com_etiqueta_ativa()
- trg_bloqueia_inativar_modelo_com_etiqueta_ativa
- ck_modelo_etiqueta_nome_tamanho
- ck_modelo_etiqueta_observacao_tamanho
- ck_modelo_etiqueta_dpi_positivo
- ck_modelo_etiqueta_largura_positiva
- ck_modelo_etiqueta_altura_positiva

REGRAS PRESERVADAS
- Unicidade global por upper(trim(nome_modelo_etiqueta)) + versao.
- Mesmo nome com versao diferente permitido.
- Trigger somente na transicao ativo -> inativo.
- Etiqueta ativa bloqueia inativacao do modelo.
- Etiqueta inativa nao bloqueia inativacao do modelo.
- Check de versao antigo preservado.
- Check de ZPL antigo preservado.
- Check de nome nao vazio, se existente, preservado.
- Nenhuma exclusao ou atualizacao de dados reais.

REVISAO ESTATICA
- Conferida presenca dos nove arquivos.
- Conferida ausencia de scripts PRD.
- Conferida presenca de \set ON_ERROR_STOP on nos oito scripts SQL.
- Conferida presenca de SET LOCAL lock_timeout e statement_timeout em aplicar/rollback.
- Conferida presenca de comentarios de propriedade para rollback seguro.
- Conferida presenca dos testes transacionais com ROLLBACK.
- Verificacao sintatica possivel neste ambiente: revisao textual/estatica dos scripts SQL.
  Observacao: nao houve conexao a PostgreSQL real e nenhum script foi executado.
