# FugaPET - Incremental 036 - Regras de banco do Cadastro de Etiqueta - FINAL GAIA

Responsavel pelo projeto: Michael Richard
Status: pacote gerado pela Gaia para revisao da Minerva. Nao executar em PRD.
Comentario de propriedade dos objetos criados: FugaPET incremental 036 etiqueta

## Escopo
Este pacote reforca no PostgreSQL as regras ja validadas na EtiquetaForm:
- duplicidade global de codigo interno por upper(trim(codigo_interno));
- limites de tamanho para codigo, nome e descricao;
- bloqueio de inativacao de Etiqueta quando existir produto_etiqueta ativo vinculado;
- preservacao de ck_etiqueta_codigo_nao_vazio, ck_etiqueta_tipo, FKs, NOT NULLs e objetos legados.

## Arquivos
1. 036_etiqueta_preflight_DEV.sql
2. 036_etiqueta_aplicar_DEV.sql
3. 036_etiqueta_validar_DEV.sql
4. 036_etiqueta_rollback_DEV.sql
5. 036_etiqueta_preflight_HML.sql
6. 036_etiqueta_aplicar_HML.sql
7. 036_etiqueta_validar_HML.sql
8. 036_etiqueta_rollback_HML.sql
9. README_036_ETIQUETA_FINAL_GAIA.txt

## Objetos criados pelo pacote 036
- uq_etiqueta_codigo_interno_global
- ck_etiqueta_codigo_tamanho
- ck_etiqueta_nome_tamanho
- ck_etiqueta_descricao_tamanho
- fn_bloqueia_inativar_etiqueta_com_produto_ativo()
- trg_bloqueia_inativar_etiqueta_com_produto_ativo

## Objetos preservados
- ck_etiqueta_codigo_nao_vazio
- ck_etiqueta_tipo
- FKs existentes
- NOT NULLs existentes
- triggers genericos existentes
- logs e auditorias existentes

## Correcoes incorporadas nesta versao Gaia
- Aplicar DEV/HML remove os indices parciais legados uq_etiqueta_codigo e uq_etiqueta_codigo_interno_ativo antes de criar o indice global.
- CREATE UNIQUE INDEX nao qualifica o nome do indice com schema.
- ck_etiqueta_codigo_tamanho usa char_length(trim(codigo_interno)) BETWEEN 1 AND 80.
- Preflight lista registros problematicos e aborta com RAISE EXCEPTION se houver inconsistencia bloqueante.
- Aplicar respeita os estados PACOTE_NAO_APLICADO, PACOTE_COMPLETAMENTE_APLICADO e ESTADO_PARCIAL_OU_INCOMPATIVEL.
- Rollback remove somente objetos com comentario de propriedade do pacote 036.
- Validador evita falso positivo no teste do trigger usando flag booleana e aprovando apenas quando o bloqueio realmente ocorre.
- Validador confirma ausencia dos indices parciais antigos apos aplicacao.
- Validador confere indice, trigger, funcao e checks por catalogos PostgreSQL e usa pg_get_*def apenas como diagnostico.
- Validador executa massa transacional e confirma residuos zero apos ROLLBACK.

- Correcao final Gaia/Minerva: validadores DEV/HML usam descricao_produto_referencia em produto_referencia.
- Preflights DEV/HML validam as colunas usadas pela massa transacional em produto_referencia, produto_etiqueta e modelo_etiqueta antes da aplicacao.

## Ordem de implantacao recomendada
1. Preflight DEV.
2. Aplicacao DEV.
3. Validacao DEV.
4. Teste da aplicacao em DEV.
5. Preflight HML.
6. Backup HML.
7. Aplicacao HML.
8. Validacao HML.
9. Preflight pos-aplicacao HML.
10. Revalidacao documental.

Rollback nao faz parte do fluxo normal.

## Comandos psql
Executar sempre com ON_ERROR_STOP externo, mesmo que a diretiva exista dentro dos arquivos:

psql -v ON_ERROR_STOP=1 -f 036_etiqueta_preflight_DEV.sql
psql -v ON_ERROR_STOP=1 -f 036_etiqueta_aplicar_DEV.sql
psql -v ON_ERROR_STOP=1 -f 036_etiqueta_validar_DEV.sql
psql -v ON_ERROR_STOP=1 -f 036_etiqueta_preflight_HML.sql
psql -v ON_ERROR_STOP=1 -f 036_etiqueta_aplicar_HML.sql
psql -v ON_ERROR_STOP=1 -f 036_etiqueta_validar_HML.sql

## Mensagens finais esperadas
- OK - PREFLIGHT 036 DEV concluido sem inconsistencias bloqueantes
- OK - APLICACAO 036 DEV concluida
- OK - regras de banco do Cadastro de Etiqueta validadas (DEV)
- OK - PREFLIGHT 036 HML concluido sem inconsistencias bloqueantes
- OK - APLICACAO 036 HML concluida
- OK - regras de banco do Cadastro de Etiqueta validadas (HML)

## Confirmacoes da geracao Gaia
- Nenhum script foi executado.
- Nenhum dado foi alterado.
- Nenhum rollback foi executado.
- Nenhum commit foi realizado.
- Nenhum codigo C# foi alterado.
- PRD nao foi incluido.
