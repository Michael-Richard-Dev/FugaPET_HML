FUGAPET - INCREMENTAL 044 HML - REV2 CONSOLIDADA / COMPATIBILIDADE COM AUDITORIA LEGADA
Responsavel: Michael Richard
Agente: Gaia Dados V2
Preparacao: 2026-08-07

CLASSIFICACAO_DA_PREPARACAO=PACOTE_044_HML_REV2_COMPATIBILIDADE_LEGADA_PREPARADO_PARA_AUDITORIA_DEDALO_V5
044_HML_CLASSIFICACAO=044_HML_NUNCA_PROMOVIDO
DESCRITOR_SECUNDARIO=BASELINE_HU_LEGADA_PRESENTE_E_VAZIA
ESTRATEGIA=PROPOSTA_HML_CONSOLIDADA_EQUIVALENTE_AO_ESTADO_FINAL_DEV_POS_REV11

AMBIENTE_ALVO=HML
SERVIDOR=192.168.3.226
BANCO=fuga_jales_local_homologacao_v1_2
SCHEMA=homologacao
ROLE_RUNTIME=fugapet_hml_app
POSTGRESQL_HML=18.4
EXECUTOR_ADMINISTRATIVO=postgres

DECISAO_HERA=OPCAO_A
REV1=SUPERSEDIDO_OPERACIONALMENTE
REV2_EXECUTADA=NAO

REGRA CENTRAL REV2:
- Promover integralmente o contrato 044 final pos-REV11.
- Criar homologacao.fn_hu_registrar_log_alteracao_cadastral() como SECURITY DEFINER, owner postgres, search_path=pg_catalog.
- Redirecionar EXATAMENTE os 3 triggers HU aprovados:
  1. trg_hu_caixa_log_alteracao_cadastral
  2. trg_hu_caixa_pesagem_log_alteracao_cadastral
  3. trg_hu_caixa_integracao_sap_log_alteracao_cadastral
- Preservar fn_registrar_log_alteracao_cadastral() sem alteracao de definicao, security mode, owner ou search_path.
- Preservar todos os triggers historicos fora dos 3 triggers HU acima.
- Preservar EXATAMENTE os ACLs HML preexistentes de homologacao.log_alteracao_cadastral e da sequence de auditoria.
- Nao adicionar, ampliar, reduzir ou restaurar ACL legado nesses dois objetos: a REV2 simplesmente nao os toca.
- Aplicar aos 8 objetos HU/palete e respectivas sequences os grants equivalentes ao DEV final aprovado, com adaptacao desenvolvimento->homologacao e fugapet_dev_app->fugapet_hml_app. A unica excecao e log_alteracao_cadastral + sequence de auditoria.

EXCECAO_HML_FORMALMENTE_ACEITA:
HML_LEGACY_AUDIT_PRIVILEGE_PRESERVED=SIM
DML_DIRETO_APP_LOG_HML=PRIVILEGIO_LEGADO_TEMPORARIAMENTE_PRESENTE
CRIADA_PELA_REV2=NAO
AMPLIADA_PELA_REV2=NAO
RUNTIME_HU_NAO_DEPENDE_DML_DIRETO_LOG=SIM (prova estrutural preparada na VALIDACAO REV2)

BACKUP_HML_NECESSARIO_ANTES_DE_EVENTUAL_APLICACAO=SIM
MOTIVO=alteracao estrutural relevante sobre baseline historica, view dependente, constraints, triggers, funcoes e ACLs HU; necessidade de rollback operacional.

NESTA MISSAO:
PREFLIGHT_REV2_EXECUTADO=NAO
BACKUP_EXECUTADO=NAO
PROPOSTA_REV2_EXECUTADA=NAO
VALIDACAO_REV2_EXECUTADA=NAO
ROLLBACK_REV2_EXECUTADO=NAO
DDL_EXECUTADO=NAO
DML_EXECUTADO=NAO
SAP_ACESSADO=NAO
CPI_ACESSADO=NAO
CSHARP_ALTERADO=NAO
HML2=SUSPENSO
POSTS_REALIZADOS=0

PROXIMO_PASSO=DEDALO_V5
